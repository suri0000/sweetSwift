//
//  ViewController.swift
//  SweetSwift
//
//  Created by 예슬 on 2/27/24.
//

import UIKit

class ViewController: UIViewController {

  @IBOutlet weak var vendingMachine: UIImageView!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    
    // Do any additional setup after loading the view.
  }

  @IBAction func goYeseulButton(_ sender: UIButton) {
  }
  @IBAction func goMirimButton(_ sender: UIButton) {
  }
  @IBAction func goKwangminButton(_ sender: UIButton) {
  }
  
}

