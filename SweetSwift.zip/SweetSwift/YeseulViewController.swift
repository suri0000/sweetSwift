//
//  YeseulViewController.swift
//  SweetSwift
//
//  Created by 예슬 on 2/27/24.
//

import UIKit

class YeseulViewController: UIViewController {

  @IBOutlet weak var introduction: UITextView!
  @IBOutlet weak var yeseulMemoji: UIImageView!
  override func viewDidLoad() {
        super.viewDidLoad()

    }
  
  
}
